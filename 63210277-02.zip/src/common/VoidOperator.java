/**
 * @ Author: turk
 * @ Description:
 */

package common;

public interface VoidOperator {
    void apply();
}